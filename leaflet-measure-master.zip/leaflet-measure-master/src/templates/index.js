export { default as controlTemplate } from './control-template.html';
export { default as resultsTemplate } from './results-template.html';
export { default as pointPopupTemplate } from './point-popup-template.html';
export { default as linePopupTemplate } from './line-popup-template.html';
export { default as areaPopupTemplate } from './area-popup-template.html';
